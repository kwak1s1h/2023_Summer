public interface Payload
{
    public string GetJsonString();
    public string GetQueryString();
}