using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class LunchVO
{
    public string date;
    public List<string> menus;
}
